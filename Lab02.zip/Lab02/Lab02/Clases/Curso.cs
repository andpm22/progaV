﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lab02.Clases
{
    public class Curso
    {
        public string nombre { set; get;}
        //Private no hereda a otras clases
        private int dias { set; get; }
        //Es como private pero si se hereda esta clase si se llega a heredar el protected
        protected DateTime inicio { set; get; }

        public void AgregarAlumno(string pNombre, int pDias)
        {
            this.nombre = pNombre;
            this.dias = pDias;
            this.inicio = DateTime.Now;
        }
        public string Ejemplo(string nombre, string cedula)
        {
            return "El nombre es: " + nombre + ", la cedula es: " + cedula;
        }

        public int NumeroDias { set; get; }
        {
            return 10;
        }
    }
}