﻿using Lab02.Clases;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

//Namespace son divisiones logicas
namespace Lab02.Pages
{
    public partial class EjClases : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnEjecturar_Click(object sender, EventArgs e)
        {
            Curso objeto = new Curso();
            //objeto.AgregarAlumno("Lisandro", 100);
            //objeto.Ejemplo("Andres", "1-1521-151");
            //string texto = objeto.Ejemplo("Andres", "1-1521-151");
            txtResultado.Text = objeto.Ejemplo("Juan", "1-1521-151");
        }
    }
}