﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab02.Pages
{
    public partial class Ejercicios : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnMostrarMes_Click(object sender, EventArgs e)
        {
            try
            {
                int numero1 = Convert.ToInt32(txtNumero1.Text);
                //Rango de numeros
                if (numero1 < 1 || numero1 > 12)
                {
                    txtResultado1.Text = "N/A";
                }
                else
                {
                    //Switch para los meses
                    switch (numero1)
                    {
                        case 1:
                            txtResultado1.Text = "Enero";
                            break;
                        case 2:
                            txtResultado1.Text = "Febrero";
                            break;
                        case 3:
                            txtResultado1.Text = "Marzo";
                            break;
                        case 4:
                            txtResultado1.Text = "Abril";
                            break;
                        case 5:
                            txtResultado1.Text = "Mayo";
                            break;
                        case 6:
                            txtResultado1.Text = "Junio";
                            break;
                        case 7:
                            txtResultado1.Text = "Julio";
                            break;
                        case 8:
                            txtResultado1.Text = "Agosto";
                            break;
                        case 9:
                            txtResultado1.Text = "Setiembre";
                            break;
                        case 10:
                            txtResultado1.Text = "Octubre";
                            break;
                        case 11:
                            txtResultado1.Text = "Noviembre";
                            break;
                        case 12:
                            txtResultado1.Text = "Diciembre";
                            break;
                    }

                }
            }
            catch
            {
                //Cualquier otra cosa ingresada lo agarro aca
                txtResultado1.Text = "Error";
                txtNumero1.Text = "";
             
            }
        }

        protected void btnConcatenar_Click(object sender, EventArgs e)
        {
            try
            {
                int numero2 = Convert.ToInt32(txtNumero2.Text);
                //Rango de Numeros
                if (numero2 < 1 || numero2 > 50)
                {
                    txtResultado2.Text = "N/A";
                }
                else
                {
                    //String Builder me ayuda a concatenar
                    var sb = new System.Text.StringBuilder();
                    for (int i = numero2; i >= 0 ; i--)
                    {  
                        //Aqui concateno todo lo que tiene 'i' y lo paso al txtbox
                        txtResultado2.Text =  sb.AppendLine(" " + i.ToString()).ToString() + " ";
                    }
                }
            }
            catch
            {
                txtResultado2.Text = "Error";
                txtNumero2.Text = "";
            }
        }

        protected void btnNumerosPares_Click(object sender, EventArgs e)
        {
            try
            {
                int numero3 = Convert.ToInt32(txtNumero3.Text);
                //Rango de Numeros
                if (numero3 < 2 || numero3 > 250)
                {
                    txtResultado2.Text = "N/A";
                }
                else
                {

                    //String Builder me ayuda a concatenar
                    var sb = new System.Text.StringBuilder();

                    for (int i = 0; i <= numero3; i++)
                    {
                        //Saco el residuo de 'i'
                        int comparador = i % 2;
                        //Comparo el residuo para saber los numeros pares
                        if (comparador == 0)
                        {
                            txtResultado3.Text = " " + sb.AppendLine(" " + i.ToString()).ToString() + " ";
                        }

                    }

                }
            }
            catch
            {
                txtResultado3.Text = "Error";
                txtNumero3.Text = "";

            }
        }
    }
}