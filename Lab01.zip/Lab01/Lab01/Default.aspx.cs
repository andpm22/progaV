﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab01
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnOcultarTexto_Click(object sender, EventArgs e)
        {
            lblTexto.Visible = false;

        }

        protected void btnMostrarTexto_Click(object sender, EventArgs e)
        {
            lblTexto.Visible = true;

        }

        protected void btnCambiarTexto_Click(object sender, EventArgs e)
        {
            lblTexto.Text = "Hola";

        }

        protected void btnGestionarTexto_Click(object sender, EventArgs e)
        {
            bool estadoDelBton = lblTexto.Visible;
            if (estadoDelBton == true)
            {
                lblTexto.Visible = false;
                btnGestionarTexto.Text = "Prender";
            }
            else
            {
                lblTexto.Visible = true;
                btnGestionarTexto.Text = "Apagar";
            }


        }

        protected void btnMostrarFecha_Click(object sender, EventArgs e)
        {
            txtFechaHora.Text = DateTime.Now.ToString();
            txtFechaHora.Enabled = false;
        }

        protected void btnSumar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNu1.Text == "" || txtNu2.Text == "")
                {
                    txtResultado.Text = "N/A";
                }
                else
                {
                    //Formas de convertir un string a int
                    int numero1 = Convert.ToInt32(txtNu1.Text);
                    int numero2 = int.Parse(txtNu2.Text);
                    int resultado = numero1 + numero2;
                    txtResultado.Text = resultado.ToString();
                }
            }
            catch
            {
                txtResultado.Text = "Error con sus datos";
                txtNu1.Text = "";
                txtNu2.Text = "";
            }
              

        }

        protected void btnRestar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNu1.Text == "" || txtNu2.Text == "")
                {
                    txtResultado.Text = "N/A";
                }
                else
                {
                    //Formas de convertir un string a int
                    int numero1 = Convert.ToInt32(txtNu1.Text);
                    int numero2 = int.Parse(txtNu2.Text);
                    int resultado = numero1 - numero2;
                    txtResultado.Text = resultado.ToString();
                }
            }
            catch
            {
                txtResultado.Text = "Error con sus datos";
                txtNu1.Text = "";
                txtNu2.Text = "";
            }
        }

        protected void btnDividir_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNu1.Text == "" || txtNu2.Text == "")
                {
                    txtResultado.Text = "N/A";
                }
                else
                {
                    //Formas de convertir un string a int
                    int numero1 = Convert.ToInt32(txtNu1.Text);
                    int numero2 = int.Parse(txtNu2.Text);
                    int resultado = numero1 / numero2;
                    txtResultado.Text = resultado.ToString();
                }
            }
            catch
            {
                txtResultado.Text = "Error con sus datos";
                txtNu1.Text = "";
                txtNu2.Text = "";
            }
        }

        protected void btnMultiplicar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNu1.Text == "" || txtNu2.Text == "")
                {
                    txtResultado.Text = "N/A";
                }
                else
                {
                    //Formas de convertir un string a int
                    int numero1 = Convert.ToInt32(txtNu1.Text);
                    int numero2 = int.Parse(txtNu2.Text);
                    int resultado = numero1 * numero2;
                    txtResultado.Text = resultado.ToString();
                }
            }
            catch
            {
                txtResultado.Text = "Error con sus datos";
                txtNu1.Text = "";
                txtNu2.Text = "";
            }
        }

        protected void btnSumatoria_Click(object sender, EventArgs e)
        {
            int numeroSumatoria = int.Parse(txtSumatoriaNumero.Text);
            int resultadoSumatoria = 0;
            for (int i = 0; i <= numeroSumatoria; i++)
            {
                //resultadoSumatoria = resultadoSumatoria + i;
                resultadoSumatoria += i;
            }
            TextSumatoriaResulado.Text = resultadoSumatoria.ToString();
            TextSumatoriaResulado.Enabled = false;
        }
    }
}